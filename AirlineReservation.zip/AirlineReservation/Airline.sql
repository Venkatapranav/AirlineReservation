delete from ticket;
