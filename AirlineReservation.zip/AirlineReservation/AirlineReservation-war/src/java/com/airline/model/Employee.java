/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.airline.model;

import com.airline.ejb.EmployeeSessionLocal;

import java.io.IOException;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import javax.ejb.EJB;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;

/**
 *
 * @author vensinga
 */
@Named(value = "employee")
@SessionScoped
public class Employee implements Serializable {

    /**
     * Creates a new instance of Employee
     */
    public Employee() {
    }
    
    private Integer employeeid;
    
    private String name;
    
    private String phoneno;
    
    private String jobtitle;
    // @Pattern(regexp="[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?", message="Invalid email")//if the field contains email address consider using this annotation to enforce field validation
   
    private String email;
    
    private String password;

    @EJB
    EmployeeSessionLocal local;

    public Integer getEmployeeid() {
        return employeeid;
    }

    public void setEmployeeid(Integer employeeid) {
        this.employeeid = employeeid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhoneno() {
        return phoneno;
    }

    public void setPhoneno(String phoneno) {
        this.phoneno = phoneno;
    }

    public String getJobtitle() {
        return jobtitle;
    }

    public void setJobtitle(String jobtitle) {
        this.jobtitle = jobtitle;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public EmployeeSessionLocal getLocal() {
        return local;
    }

    public void setLocal(EmployeeSessionLocal local) {
        this.local = local;
    }

    @Override
    public String toString() {
        return "Employee{" + "employeeid=" + employeeid + ", name=" + name + ", phoneno=" + phoneno + ", jobtitle=" + jobtitle + ", email=" + email + ", password=" + password + ", local=" + local + '}';
    }
    
    public String verifyEmployee(){
        
        com.airline.entity.Employee emp=local.verifyEmployee(email);;
        name=emp.getEmployeeName();
        if(emp.getPassword().equals(password)){
            return "empSuccess";
        }
        
        else return "empFail";
    }
    public void logout() throws IOException {
    ExternalContext ec = FacesContext.getCurrentInstance().getExternalContext();
    ec.invalidateSession();
    ec.redirect(ec.getRequestContextPath() + "/index.xhtml");
}
    
}
