/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.airline.model;

import com.airline.ejb.SeatBookingLocal;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.inject.Named;
import javax.enterprise.context.Dependent;
import javax.enterprise.context.SessionScoped;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.RequestScoped;
import javax.inject.Inject;

/**
 *
 * @author vadas
 */
@Named(value = "smallSeatPlan")

@SessionScoped

public class SmallSeatPlan implements Serializable{
    @EJB
    SeatBookingLocal local;
   
    private List<String> seats;
    private List<String> seatsE;
    private List<String> selectedSeatsB;
    private List<String> selectedSeatsE;
    private List<String> bookedSeats;
    private List<String> passengers;
    private List<String> selectedSeats;
   
    @Inject
    private Route r;
   

    public Route getR() {
        return r;
    }

    public void setR(Route r) {
        this.r = r;
    }

 
    public List<String> getSelectedSeatsB() {
        return selectedSeatsB;
    }

    public void setSelectedSeatsB(List<String> selectedSeatsB) {
        this.selectedSeatsB = selectedSeatsB;
    }

    public List<String> getSelectedSeatsE() {
        return selectedSeatsE;
    }

    public void setSelectedSeatsE(List<String> selectedSeatsE) {
        this.selectedSeatsE = selectedSeatsE;
    }


    public List<String> getSelectedSeats() {
        return selectedSeats;
    }

    public void setSelectedSeats(List<String> selectedSeats) {
        this.selectedSeats = selectedSeats;
    }
    public SeatBookingLocal getLocal() {
        return local;
    }

    public void setLocal(SeatBookingLocal local) {
        this.local = local;
    }

  

    public List<String> getPassengers() {
        return passengers;
    }

    public void setPassengers(List<String> passengers) {
        this.passengers = passengers;
    }
    public List<String> getBookedSeats() {
        return bookedSeats;
    }

    public void setBookedSeats(List<String> bookedSeats) {
        this.bookedSeats = bookedSeats;
    }
 
    
    
    public List<String> getSeatsE() {
        return seatsE;
    }

    public void setSeatsE(List<String> seatsE) {
        this.seatsE = seatsE;
    }

//    public String[] getSelectedSeats() {
//        return selectedSeats;
//    }
//
//    public void setSelectedSeats(String[] selectedSeats) {
//        this.selectedSeats = selectedSeats;
//    }
//   


    public List<String> getSeats() {
        return seats;
    }

    public void setSeats(List<String> seats) {
        this.seats = seats;
    }
   
     @PostConstruct
    public void init() {
        seats = new ArrayList<String>();
       for(int i=1;i<=12;i++){
           seats.add("B"+i);
       }
        
        seatsE = new ArrayList<String>();
        for(int i=1;i<=40;i++){
           seatsE.add("E"+i);
       }
        
        selectedSeatsB = new ArrayList<String>();
        selectedSeatsE = new ArrayList<String>();
        selectedSeats = new ArrayList<String>(selectedSeatsB);
        selectedSeats.addAll(selectedSeatsE);
        selectedSeats.add("E4");
        selectedSeats.add("B4");
        System.out.println(r.getF().getFlightId());
        System.out.println(r.getDate());
        
        bookedSeats = local.getBookedSeats(r.getF().getFlightId(),r.getDate());
        System.out.println(bookedSeats);
        
        
    }
   
    public SmallSeatPlan() {
    }
    
}
