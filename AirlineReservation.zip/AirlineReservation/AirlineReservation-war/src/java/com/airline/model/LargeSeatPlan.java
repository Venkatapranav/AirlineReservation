/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.airline.model;

import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.inject.Named;
import javax.enterprise.context.Dependent;

/**
 *
 * @author vadas
 */
@Named(value = "largeSeatPlan")
@Dependent
public class LargeSeatPlan {

       private List<String> seats;
     @PostConstruct
    public void init() {
        seats = new ArrayList<String>();
        seats.add("B01");
        seats.add("B02");
        seats.add("B03");
        seats.add("B04");
        seats.add("E01");
        seats.add("E02");
        seats.add("E03");
        seats.add("E04");
    }
    public List<String> getSeats() {
        return seats;
    }

    public void setSeats(List<String> seats) {
        this.seats = seats;
    }
    public LargeSeatPlan() {
    }
    
}
