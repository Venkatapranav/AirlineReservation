/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.airline.model;

import com.airline.ejb.FaresSessionLocal;
import com.airline.ejb.FlightLocal;
import com.airline.ejb.PlaneSessionLocal;
import com.airline.ejb.RouteLocal;
import com.airline.entity.Fare;
import com.airline.entity.Flight;
import com.airline.entity.Plane;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;

import java.util.ArrayList;
import java.util.Date;

import java.util.List;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.persistence.Column;
import javax.validation.constraints.Size;

/**
 *
 * @author vensinga
 */
@Named(value = "route")

@SessionScoped
public class Route implements Serializable {

   
    public Route() {
    }
    @EJB
    RouteLocal localRoute;
    
    @EJB
    FlightLocal localFlight;
    
    @EJB
    PlaneSessionLocal localPlane;
    
    @EJB
    FaresSessionLocal localFare;
    
    private Integer routeId;
  
    private String startingFrom;
   
    private String destination;
    
    private Date date;
    
    private FlightDisplay f;

    public FlightDisplay getF() {
        return f;
    }

    public void setF(FlightDisplay f) {
        this.f = f;
    }

  
    private List<FlightDisplay> flightDisplay;
    public List<FlightDisplay> getFlightDisplay() {
        return flightDisplay;
    }

    public void setFlightDisplay(List<FlightDisplay> flightDisplay) {
        this.flightDisplay = flightDisplay;
    }
    
    public PlaneSessionLocal getLocalPlane() {
        return localPlane;
    }

    public void setLocalPlane(PlaneSessionLocal localPlane) {
        this.localPlane = localPlane;
    }

    public FaresSessionLocal getLocalFare() {
        return localFare;
    }

    public void setLocalFare(FaresSessionLocal localFare) {
        this.localFare = localFare;
    }

    public RouteLocal getLocalRoute() {
        return localRoute;
    }

    public void setLocalRoute(RouteLocal localRoute) {
        this.localRoute = localRoute;
    }

    public FlightLocal getLocalFlight() {
        return localFlight;
    }

    public void setLocalFlight(FlightLocal localFlight) {
        this.localFlight = localFlight;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Integer getRouteId() {
        return routeId;
    }

    public void setRouteId(Integer routeId) {
        this.routeId = routeId;
    }

    public String getStartingFrom() {
        return startingFrom;
    }

    public void setStartingFrom(String startingFrom) {
        this.startingFrom = startingFrom;
        System.out.println(this.startingFrom);
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }
    
    public String getRoute(){
        
        System.out.println(this.startingFrom);
        System.out.println(this.destination);
        System.out.println("dfsdfsdfd");
        flightDisplay = new ArrayList<>();
       Integer rId= localRoute.getRouteid(startingFrom, destination);
       java.sql.Date sqlDate = new java.sql.Date(date.getTime());
      
      List<Flight> flight=localFlight.getFlights(sqlDate, rId);
      // planeType;
      
      
     flight.forEach((Flight f) -> {
          double Efare, Bfare;
           Plane    p=f.getPlaneId();
           String   planeType=p.getPlaneType();
          FlightDisplay fd=new FlightDisplay();
         Fare fare=localFare.getfare(rId,planeType);
         Bfare=fare.getBusinessFare();
         Efare=fare.getEconomyFare();
     
           fd.setType(planeType);
           fd.setFlightId(f.getFlightId());
           fd.setBusinessFare(Bfare);
           fd.setEconomyFare(Efare);
           fd.setArrTime( f.getArrTime());
           fd.setDeptTime( f.getDeptTime());
           
           flightDisplay.add(fd);
           
        });
      
     System.out.println(flightDisplay);
      //Plane p=localPlane.getPlane(flight.getPlaneid());
  
      return "success";
       
    }
    private String txt1;

    public String getTxt1() {
        return txt1;
    }

    public void setTxt1(String txt1) {
        this.txt1 = txt1;
    }
    
     
    
    public List<String> completeText(String query) {
        List<String> results = new ArrayList<String>();
        for(int i = 0; i < 10; i++) {
            results.add("city" + i);
        }
         
        return results;
    }
    
    public String goToSeatPlan(String type,FlightDisplay fd){
        f = fd;
        if(type.equals("small"))
            return "small";
        else return "large";
    }
}
