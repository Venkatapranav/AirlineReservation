/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.airline.model;

import com.airline.ejb.FlightLocal;
import com.airline.ejb.PlaneSessionLocal;
import com.airline.ejb.RouteLocal;
import com.airline.entity.Plane;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.ejb.EJB;

/**
 *
 * @author vensinga
 */
@Named(value = "addFlights")
@SessionScoped
public class AddFlights implements Serializable {

    /**
     * Creates a new instance of AddFlights
     */
    
   @EJB
    FlightLocal localFlight;
    
    @EJB
    RouteLocal localRoute;
    
    @EJB
    PlaneSessionLocal localPlane;
    
    
    private com.airline.entity.Plane plane;
    private Date deptDate;
    private String deptTime;
    private Date arrDate;
    private String arrTime;
    private String source;
    private String destination;
    private Integer flightId;
    private Integer planeId;

    public Integer getFlightId() {
        return flightId;
    }

    public void setFlightId(Integer flightId) {
        this.flightId = flightId;
    }
    

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }
    

    public FlightLocal getLocalFlight() {
        return localFlight;
    }

    public RouteLocal getLocalRoute() {
        return localRoute;
    }

    public void setLocalRoute(RouteLocal localRoute) {
        this.localRoute = localRoute;
    }

   
    
    public void setLocalFlight(FlightLocal localFlight) {
        this.localFlight = localFlight;
    }

    public PlaneSessionLocal getLocalPlane() {
        return localPlane;
    }

    public void setLocalPlane(PlaneSessionLocal localPlane) {
        this.localPlane = localPlane;
    }

    public Plane getPlane() {
        return plane;
    }

    public void setPlane(Plane plane) {
        this.plane = plane;
    }

    public Integer getPlaneId() {
        return planeId;
    }

    public void setPlaneId(Integer planeId) {
        this.planeId = planeId;
    }

  

    

    
    public Date getDeptDate() {
        return deptDate;
    }

    public void setDeptDate(Date deptDate) {
        this.deptDate = deptDate;
    }

    public String getDeptTime() {
        return deptTime;
    }

    public void setDeptTime(String deptTime) {
        this.deptTime = deptTime;
    }

    public Date getArrDate() {
        return arrDate;
    }

    public void setArrDate(Date arrDate) {
        this.arrDate = arrDate;
    }

    public String getArrTime() {
        return arrTime;
    }

    public void setArrTime(String arrTime) {
        this.arrTime = arrTime;
    }
    
    
    public AddFlights() {
    }
    
    public String addFlights(){
        
        com.airline.entity.Flight flight=new com.airline.entity.Flight();
        flight.setArrTime(arrDate);
        flight.setDeptTime(deptDate);
        flight.setFlightId(flightId);
        plane=localPlane.getPlane(planeId);
       Integer routeId=localRoute.getRouteId(source, destination);
        flight.setPlaneId(plane);
       com.airline.entity.Route route=new com.airline.entity.Route();
       route.setRouteId(routeId);
       route.setDestination(destination);
       route.setStartingFrom(destination);
        flight.setRouteId(route);
        localFlight.addNewFlight(flight);
        return "success";
  }
private String txt1;

    public String getTxt1() {
        return txt1;
    }

    public void setTxt1(String txt1) {
        this.txt1 = txt1;
    }

    public List<String> completeText(String query) {
        List<String> results = new ArrayList<String>();
        for (int i = 0; i < 10; i++) {
            results.add("city" + i);
        }

        return results;
    }
}