/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.airline.model;

import com.airline.ejb.FlightDetailsLocal;
import com.airline.ejb.FlightDetails;
import com.airline.entity.Flight;
import java.util.Date;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.inject.Named;
import javax.enterprise.context.Dependent;

/**
 *
 * @author vadas
 */
@Named(value = "flightDetailsBean")
@Dependent
public class FlightDetailsBean {
    private List<Flight> flightList;
    private Long flightId;
    private Date depTime;
    private Date arrTime;
    private Long ecoFare;
    private Long bussFare;
    private Integer availableSeats;
    @EJB
    FlightDetailsLocal local;
    
    @PostConstruct
    public void init(){
        
//        flightList = local.getFlights(1);
//        flightList.forEach(flight ->
//        {
//            flightId  = flight.getFlightId();
//            depTime = flight.getDeptTime();
//            arrTime = flight.getArrTime();
//        });
    }

    public Long getFlightId() {
        return flightId;
    }

    public void setFlightId(Long flightId) {
        this.flightId = flightId;
    }

    public Date getDepTime() {
        return depTime;
    }

    public void setDepTime(Date depTime) {
        this.depTime = depTime;
    }

    public Date getArrTime() {
        return arrTime;
    }

    public void setArrTime(Date arrTime) {
        this.arrTime = arrTime;
    }

    public Long getEcoFare() {
        return ecoFare;
    }

    public void setEcoFare(Long ecoFare) {
        this.ecoFare = ecoFare;
    }

    public Long getBussFare() {
        return bussFare;
    }

    public void setBussFare(Long bussFare) {
        this.bussFare = bussFare;
    }

    public Integer getAvailableSeats() {
        return availableSeats;
    }

    public void setAvailableSeats(Integer availableSeats) {
        this.availableSeats = availableSeats;
    }

    public List getFlightList() {
        return flightList;
    }

    public void setFlightList(List flightList) {
        this.flightList = flightList;
    }
    
    public FlightDetailsBean() {
    }
    
   
}
