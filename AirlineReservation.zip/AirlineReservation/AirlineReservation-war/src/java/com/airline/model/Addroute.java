/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.airline.model;

import com.airline.ejb.RouteLocal;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import javax.ejb.EJB;
import javax.persistence.Column;
import javax.validation.constraints.Size;

/**
 *
 * @author vensinga
 */
@Named(value = "addroute")
@SessionScoped
public class Addroute implements Serializable {

    /**
     * Creates a new instance of Addroute
     */
    private Integer routeid;
   
    private String startingfrom;
    
    private String destination;
     
    public Addroute() {
    }

    @EJB
    RouteLocal localRoute;

    public Integer getRouteid() {
        return routeid;
    }

    public void setRouteid(Integer routeid) {
        this.routeid = routeid;
    }

    public String getStartingfrom() {
        return startingfrom;
    }

    public void setStartingfrom(String startingfrom) {
        this.startingfrom = startingfrom;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public RouteLocal getLocalRoute() {
        return localRoute;
    }

    public void setLocalRoute(RouteLocal localRoute) {
        this.localRoute = localRoute;
    }
    
    public String addNewRoute(){
        
        com.airline.entity.Route route =new com.airline.entity.Route();
        route.setRouteId(routeid);
        route.setDestination(destination);
        route.setStartingFrom(startingfrom);
        
        localRoute.addNewRoute(route);
        return "success";
    }
    
}
