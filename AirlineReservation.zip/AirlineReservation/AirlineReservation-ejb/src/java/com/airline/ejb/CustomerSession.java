/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.airline.ejb;

import com.airline.entity.Customer;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author vensinga
 */
@Stateless(mappedName="airlinereservation/ejb/customer")
public class CustomerSession implements CustomerLocal {

    @PersistenceContext(name = "AirlineReservation-ejbPU")
    EntityManager manager;
   
    @Override
    public boolean addCustomer(Customer cust) {
        
       manager.merge(cust);
       return true;
// throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")

    @Override
    public Customer verifyCustomer(String email) {
        
        Query q=manager.createNamedQuery("Customer.findByEmail",Customer.class);
        q.setParameter("email", email);
        
        return (Customer)q.getSingleResult();
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
