/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.airline.ejb;

import com.airline.entity.Customer;
import javax.ejb.Local;

/**
 *
 * @author vensinga
 */
@Local
public interface CustomerLocal {
    
    public boolean addCustomer(Customer cust);
    public Customer verifyCustomer(String email);
}
