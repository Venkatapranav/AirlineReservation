/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.airline.ejb;

import javax.ejb.Stateless;

/**
 *
 * @author vadas
 */
@Stateless
public class TicketEntrySession implements TicketEntrySessionLocal {

    @Override
    public void insert() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
