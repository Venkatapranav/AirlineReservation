/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.airline.ejb;

import com.airline.entity.Flight;
import com.airline.entity.Ticket;
import java.util.Date;
import java.util.List;
import java.util.Map;
import javax.ejb.Local;

/**
 *
 * @author adcheruk
 */
@Local
public interface RevenueLocal {
    public Map<Date,Double> generateStats(Date startDate,Date endDate);
    public List<Ticket> getTicketListFromTicket(Date startDate,Date endDate);
    
}
