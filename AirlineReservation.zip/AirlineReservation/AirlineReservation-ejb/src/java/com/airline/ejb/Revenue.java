/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.airline.ejb;

import com.airline.entity.Flight;
import com.airline.entity.Route;
import com.airline.entity.Ticket;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author adcheruk
 */
@Stateless
public class Revenue implements RevenueLocal {

    @PersistenceContext(name="AirlineReservation-ejbPU")
    EntityManager entityManager;
    
    
    @Override
    public Map<Date,Double> generateStats(Date startDate,Date endDate){
      List<Ticket> tcktList = getTicketListFromTicket(startDate, endDate);
      Map<Date,Double> dateRevenue = new HashMap<>();
      //DateFormat df = new SimpleDateFormat("dd/MM/YYYY");
      System.out.println(tcktList);
      System.out.println(tcktList.get(0));
      System.out.println(tcktList.get(1));
      
      tcktList.forEach((Ticket tckt) -> {
          //String date = df.format(tckt.getDoj());
          Date date = tckt.getDoj();
            if (dateRevenue.containsKey(date)) {
                
                dateRevenue.put(date,dateRevenue.get(date)+tckt.getFare());
            }
              else{
                dateRevenue.put(date,tckt.getFare());
            }
        });
      return dateRevenue;
    }

    @Override
    public List<Ticket> getTicketListFromTicket(Date startDate, Date endDate) {
        
        Query q = entityManager.createNativeQuery("select * from Ticket t where status='booked' and doj between ? and ?",Ticket.class);
        q.setParameter(1,startDate);
        q.setParameter(2,endDate);
        
        return q.getResultList();
    }

}
