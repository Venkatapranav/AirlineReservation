/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.airline.ejb;


import com.airline.entity.Employee;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author vensinga
 */
@Stateless(mappedName="airline/ejb/employee")
public class EmployeeSession implements EmployeeSessionLocal {

    @PersistenceContext(name = "AirlineReservation-ejbPU")
    EntityManager manager;
    
    @Override
    public Employee verifyEmployee(String email) {
        
Query q=manager.createNamedQuery("Employee.findByEmail",Employee.class);
        q.setParameter("email", email);
        
        return (Employee)q.getSingleResult();
//throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
}
