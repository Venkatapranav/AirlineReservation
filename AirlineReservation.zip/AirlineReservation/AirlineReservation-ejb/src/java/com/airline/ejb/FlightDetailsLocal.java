/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.airline.ejb;

import com.airline.entity.Flight;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author vadas
 */
@Local
public interface FlightDetailsLocal {
    public List<Flight> getFlights(Integer routeId);
}
