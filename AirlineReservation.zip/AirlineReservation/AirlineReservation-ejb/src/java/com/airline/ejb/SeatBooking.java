/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.airline.ejb;

import com.airline.entity.Flight;
import com.airline.entity.Ticket;
import java.util.Date;
import java.util.List;
import javax.ejb.Stateful;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author vadas
 */
@Stateless(mappedName="airlinereservation/ejb/seat")
public class SeatBooking implements SeatBookingLocal {
    @PersistenceContext(name="AirlineReservation-ejbPU")
          
    EntityManager manager;
    @Override
    public List<String> getBookedSeats(Integer flightId,Date doj) {
        Query q = manager.createNativeQuery("SELECT SEAT_NO FROM TICKET WHERE FLIGHT_ID=? AND DOJ=? AND STATUS='booked'");
        
        q.setParameter(1,flightId );
        q.setParameter(2,doj );
        return q.getResultList();
    }

}
