/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.airline.ejb;

import com.airline.entity.Flight;
import com.airline.entity.Ticket;
import java.util.List;
import javax.ejb.Stateful;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author vadas
 */
@Stateful
public class SeatBooking implements SeatBookingLocal {
    @PersistenceContext(name="AirlineReservation-ejbPU")
          
    EntityManager manager;
    @Override
    public List<String> getBookedSeats(Integer flightId) {
        Query q = manager.createNamedQuery("Ticket.findByFlightId",Ticket.class);
        q.setParameter("flightId",flightId );
        return q.getResultList();
    }

}
