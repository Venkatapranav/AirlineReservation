/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.airline.ejb;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author vensinga
 */
@Stateless(mappedName="airlinereservation/ejb/route")
public class RouteSession implements RouteLocal {
    
@PersistenceContext(name = "AirlineReservation-ejbPU")
    
        EntityManager manager;

  


    
    @Override
    public Long getRouteid(String source, String destination) {
       
        
       Query q= manager.createNamedQuery("Route.findByStartingfrom",RouteSession.class);
             //+ "and r.destination=:destination",Route.class);
           q.setParameter("startingFrom", source);
             //System.out.println((Route)q.getSingleResult()+"hjhwjfhje");
             //q.setParameter("destination", destination);
             
           //Query q=manager.createNamedQuery("Route.findAll",Route.class);
           
                //  Integer result=(Integer) q.getSingleResult().hashCode();
                //  return source.indexOf("H");
              
              //  if(source.equals("Hyderabad")&&destination.equals("Banglore"))return 1;
              com.airline.entity.Route r=(com.airline.entity.Route) q.getSingleResult();
              return  r.getRouteId();
//throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
}
