/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.airline.ejb;

import com.airline.entity.Flight;
import java.util.List;
import javax.ejb.Stateful;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author vadas
 */
@Stateful
public class FlightDetails implements FlightDetailsLocal {
    @PersistenceContext(name="AirlineReservation-ejbPU")
          
    EntityManager manager;
    @Override
    public List<Flight> getFlights(Integer routeId) {
       Query q = manager.createNamedQuery("Flight.findAll",Flight.class);
        return q.getResultList();
    }

}
