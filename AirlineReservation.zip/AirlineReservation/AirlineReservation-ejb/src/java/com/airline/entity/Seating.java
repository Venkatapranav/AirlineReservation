/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.airline.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author vadas
 */
@Entity
@Table(name = "SEATING")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Seating.findAll", query = "SELECT s FROM Seating s"),
    @NamedQuery(name = "Seating.findBySeatNo", query = "SELECT s FROM Seating s WHERE s.seatingPK.seatNo = :seatNo"),
    @NamedQuery(name = "Seating.findByFlightId", query = "SELECT s FROM Seating s WHERE s.seatingPK.flightId = :flightId"),
    @NamedQuery(name = "Seating.findByDeptTime", query = "SELECT s FROM Seating s WHERE s.seatingPK.deptTime = :deptTime"),
    @NamedQuery(name = "Seating.findByStatus", query = "SELECT s FROM Seating s WHERE s.status = :status")})
public class Seating implements Serializable {

    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected SeatingPK seatingPK;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "STATUS")
    private String status;
    @JoinColumn(name = "FLIGHT_ID", referencedColumnName = "FLIGHT_ID", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Flight flight;

    public Seating() {
    }

    public Seating(SeatingPK seatingPK) {
        this.seatingPK = seatingPK;
    }

    public Seating(SeatingPK seatingPK, String status) {
        this.seatingPK = seatingPK;
        this.status = status;
    }

    public Seating(String seatNo, int flightId, Date deptTime) {
        this.seatingPK = new SeatingPK(seatNo, flightId, deptTime);
    }

    public SeatingPK getSeatingPK() {
        return seatingPK;
    }

    public void setSeatingPK(SeatingPK seatingPK) {
        this.seatingPK = seatingPK;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Flight getFlight() {
        return flight;
    }

    public void setFlight(Flight flight) {
        this.flight = flight;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (seatingPK != null ? seatingPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Seating)) {
            return false;
        }
        Seating other = (Seating) object;
        if ((this.seatingPK == null && other.seatingPK != null) || (this.seatingPK != null && !this.seatingPK.equals(other.seatingPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.airline.entity.Seating[ seatingPK=" + seatingPK + " ]";
    }
    
}
