/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.airline.entity;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author vadas
 */
@Entity
@Table(name = "SEATING")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Seating.findAll", query = "SELECT s FROM Seating s")
    , @NamedQuery(name = "Seating.findByPlaneType", query = "SELECT s FROM Seating s WHERE s.planeType = :planeType")
    , @NamedQuery(name = "Seating.findByBWidth", query = "SELECT s FROM Seating s WHERE s.bWidth = :bWidth")
    , @NamedQuery(name = "Seating.findByEWidth", query = "SELECT s FROM Seating s WHERE s.eWidth = :eWidth")
    , @NamedQuery(name = "Seating.findByBLenth", query = "SELECT s FROM Seating s WHERE s.bLenth = :bLenth")
    , @NamedQuery(name = "Seating.findByELength", query = "SELECT s FROM Seating s WHERE s.eLength = :eLength")})
public class Seating implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "PLANE_TYPE")
    private String planeType;
    @Basic(optional = false)
    @NotNull
    @Column(name = "B_WIDTH")
    private long bWidth;
    @Basic(optional = false)
    @NotNull
    @Column(name = "E_WIDTH")
    private long eWidth;
    @Basic(optional = false)
    @NotNull
    @Column(name = "B_LENTH")
    private long bLenth;
    @Basic(optional = false)
    @NotNull
    @Column(name = "E_LENGTH")
    private long eLength;

    public Seating() {
    }

    public Seating(String planeType) {
        this.planeType = planeType;
    }

    public Seating(String planeType, long bWidth, long eWidth, long bLenth, long eLength) {
        this.planeType = planeType;
        this.bWidth = bWidth;
        this.eWidth = eWidth;
        this.bLenth = bLenth;
        this.eLength = eLength;
    }

    public String getPlaneType() {
        return planeType;
    }

    public void setPlaneType(String planeType) {
        this.planeType = planeType;
    }

    public long getBWidth() {
        return bWidth;
    }

    public void setBWidth(long bWidth) {
        this.bWidth = bWidth;
    }

    public long getEWidth() {
        return eWidth;
    }

    public void setEWidth(long eWidth) {
        this.eWidth = eWidth;
    }

    public long getBLenth() {
        return bLenth;
    }

    public void setBLenth(long bLenth) {
        this.bLenth = bLenth;
    }

    public long getELength() {
        return eLength;
    }

    public void setELength(long eLength) {
        this.eLength = eLength;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (planeType != null ? planeType.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Seating)) {
            return false;
        }
        Seating other = (Seating) object;
        if ((this.planeType == null && other.planeType != null) || (this.planeType != null && !this.planeType.equals(other.planeType))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.airline.entity.Seating[ planeType=" + planeType + " ]";
    }
    
}
