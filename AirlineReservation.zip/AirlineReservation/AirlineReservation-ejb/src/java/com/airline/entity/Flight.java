/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.airline.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author vadas
 */
@Entity
@Table(name = "FLIGHT")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Flight.findAll", query = "SELECT f FROM Flight f WHERE f.routeId = :routeId")
    
    , @NamedQuery(name = "Flight.findByFlightId", query = "SELECT f FROM Flight f WHERE f.flightId = :flightId")
    , @NamedQuery(name = "Flight.findByArrTime", query = "SELECT f FROM Flight f WHERE f.arrTime = :arrTime")
    , @NamedQuery(name = "Flight.findByDeptTime", query = "SELECT f FROM Flight f WHERE f.deptTime = :deptTime")})
public class Flight implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "FLIGHT_ID")
    private Long flightId;
    @Basic(optional = false)
    @NotNull
    @Column(name = "ARR_TIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date arrTime;
    @Basic(optional = false)
    @NotNull
    @Column(name = "DEPT_TIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deptTime;
    @JoinColumn(name = "PLANE_ID", referencedColumnName = "PLANE_ID")
    @ManyToOne(optional = false)
    private Plane planeId;
    @JoinColumn(name = "ROUTE_ID", referencedColumnName = "ROUTE_ID")
    @ManyToOne(optional = false)
    private Route routeId;

    public Flight() {
    }

    public Flight(Long flightId) {
        this.flightId = flightId;
    }

    public Flight(Long flightId, Date arrTime, Date deptTime) {
        this.flightId = flightId;
        this.arrTime = arrTime;
        this.deptTime = deptTime;
    }

    public Long getFlightId() {
        return flightId;
    }

    public void setFlightId(Long flightId) {
        this.flightId = flightId;
    }

    public Date getArrTime() {
        return arrTime;
    }

    public void setArrTime(Date arrTime) {
        this.arrTime = arrTime;
    }

    public Date getDeptTime() {
        return deptTime;
    }

    public void setDeptTime(Date deptTime) {
        this.deptTime = deptTime;
    }

    public Plane getPlaneId() {
        return planeId;
    }

    public void setPlaneId(Plane planeId) {
        this.planeId = planeId;
    }

    public Route getRouteId() {
        return routeId;
    }

    public void setRouteId(Route routeId) {
        this.routeId = routeId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (flightId != null ? flightId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Flight)) {
            return false;
        }
        Flight other = (Flight) object;
        if ((this.flightId == null && other.flightId != null) || (this.flightId != null && !this.flightId.equals(other.flightId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.airline.entity.Flight[ flightId=" + flightId + " ]";
    }
    
}
