/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.airline.entity;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author vadas
 */
@Entity
@Table(name = "FARE")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Fare.findAll", query = "SELECT f FROM Fare f")
    , @NamedQuery(name = "Fare.findByRouteId", query = "SELECT f FROM Fare f WHERE f.farePK.routeId = :routeId")
    , @NamedQuery(name = "Fare.findByEconomyFare", query = "SELECT f FROM Fare f WHERE f.economyFare = :economyFare")
    , @NamedQuery(name = "Fare.findByBusinessFare", query = "SELECT f FROM Fare f WHERE f.businessFare = :businessFare")
    , @NamedQuery(name = "Fare.findByPlaneType", query = "SELECT f FROM Fare f WHERE f.farePK.planeType = :planeType")})
public class Fare implements Serializable {

    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected FarePK farePK;
    @Basic(optional = false)
    @NotNull
    @Column(name = "ECONOMY_FARE")
    private long economyFare;
    @Basic(optional = false)
    @NotNull
    @Column(name = "BUSINESS_FARE")
    private long businessFare;
    @JoinColumn(name = "ROUTE_ID", referencedColumnName = "ROUTE_ID", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Route route;

    public Fare() {
    }

    public Fare(FarePK farePK) {
        this.farePK = farePK;
    }

    public Fare(FarePK farePK, long economyFare, long businessFare) {
        this.farePK = farePK;
        this.economyFare = economyFare;
        this.businessFare = businessFare;
    }

    public Fare(long routeId, String planeType) {
        this.farePK = new FarePK(routeId, planeType);
    }

    public FarePK getFarePK() {
        return farePK;
    }

    public void setFarePK(FarePK farePK) {
        this.farePK = farePK;
    }

    public long getEconomyFare() {
        return economyFare;
    }

    public void setEconomyFare(long economyFare) {
        this.economyFare = economyFare;
    }

    public long getBusinessFare() {
        return businessFare;
    }

    public void setBusinessFare(long businessFare) {
        this.businessFare = businessFare;
    }

    public Route getRoute() {
        return route;
    }

    public void setRoute(Route route) {
        this.route = route;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (farePK != null ? farePK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Fare)) {
            return false;
        }
        Fare other = (Fare) object;
        if ((this.farePK == null && other.farePK != null) || (this.farePK != null && !this.farePK.equals(other.farePK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.airline.entity.Fare[ farePK=" + farePK + " ]";
    }
    
}
