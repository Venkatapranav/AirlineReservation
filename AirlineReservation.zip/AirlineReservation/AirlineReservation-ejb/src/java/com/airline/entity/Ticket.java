/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.airline.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author vadas
 */
@Entity
@Table(name = "TICKET")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Ticket.findAll", query = "SELECT t FROM Ticket t"),
    @NamedQuery(name = "Ticket.findByTicketId", query = "SELECT t FROM Ticket t WHERE t.ticketPK.ticketId = :ticketId"),
    @NamedQuery(name = "Ticket.findByCustomerId", query = "SELECT t FROM Ticket t WHERE t.ticketPK.customerId = :customerId"),
    @NamedQuery(name = "Ticket.findBySeatNo", query = "SELECT t FROM Ticket t WHERE t.seatNo = :seatNo"),
    @NamedQuery(name = "Ticket.findByDoj", query = "SELECT t FROM Ticket t WHERE t.doj = :doj"),
    @NamedQuery(name = "Ticket.findByStatus", query = "SELECT t FROM Ticket t WHERE t.status = :status"),
    @NamedQuery(name = "Ticket.findByTob", query = "SELECT t FROM Ticket t WHERE t.tob = :tob"),
    @NamedQuery(name = "Ticket.findByPassenger", query = "SELECT t FROM Ticket t WHERE t.ticketPK.passenger = :passenger"),
    @NamedQuery(name = "Ticket.findBySsn", query = "SELECT t FROM Ticket t WHERE t.ticketPK.ssn = :ssn"),
    @NamedQuery(name = "Ticket.findByFare", query = "SELECT t FROM Ticket t WHERE t.fare = :fare")})
public class Ticket implements Serializable {

    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected TicketPK ticketPK;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "SEAT_NO")
    private String seatNo;
    @Basic(optional = false)
    @NotNull
    @Column(name = "DOJ")
    @Temporal(TemporalType.TIMESTAMP)
    private Date doj;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "STATUS")
    private String status;
    @Column(name = "TOB")
    @Temporal(TemporalType.TIMESTAMP)
    private Date tob;
    @Basic(optional = false)
    @NotNull
    @Column(name = "FARE")
    private double fare;
    @JoinColumn(name = "CUSTOMER_ID", referencedColumnName = "CUSTOMER_ID", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Customer customer;
    @JoinColumn(name = "FLIGHT_ID", referencedColumnName = "FLIGHT_ID")
    @ManyToOne(optional = false)
    private Flight flightId;

    public Ticket() {
    }

    public Ticket(TicketPK ticketPK) {
        this.ticketPK = ticketPK;
    }

    public Ticket(TicketPK ticketPK, String seatNo, Date doj, String status, double fare) {
        this.ticketPK = ticketPK;
        this.seatNo = seatNo;
        this.doj = doj;
        this.status = status;
        this.fare = fare;
    }

    public Ticket(int ticketId, int customerId, String passenger, String ssn) {
        this.ticketPK = new TicketPK(ticketId, customerId, passenger, ssn);
    }

    public TicketPK getTicketPK() {
        return ticketPK;
    }

    public void setTicketPK(TicketPK ticketPK) {
        this.ticketPK = ticketPK;
    }

    public String getSeatNo() {
        return seatNo;
    }

    public void setSeatNo(String seatNo) {
        this.seatNo = seatNo;
    }

    public Date getDoj() {
        return doj;
    }

    public void setDoj(Date doj) {
        this.doj = doj;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getTob() {
        return tob;
    }

    public void setTob(Date tob) {
        this.tob = tob;
    }

    public double getFare() {
        return fare;
    }

    public void setFare(double fare) {
        this.fare = fare;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public Flight getFlightId() {
        return flightId;
    }

    public void setFlightId(Flight flightId) {
        this.flightId = flightId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (ticketPK != null ? ticketPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Ticket)) {
            return false;
        }
        Ticket other = (Ticket) object;
        if ((this.ticketPK == null && other.ticketPK != null) || (this.ticketPK != null && !this.ticketPK.equals(other.ticketPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.airline.entity.Ticket[ ticketPK=" + ticketPK + " ]";
    }
    
}
