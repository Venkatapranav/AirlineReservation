/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.airline.entity;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author vadas
 */
@Entity
@Table(name = "ROUTE")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Route.findAll", query = "SELECT r FROM Route r")
    , @NamedQuery(name = "Route.findByRouteId", query = "SELECT r FROM Route r WHERE r.routeId = :routeId")
    , @NamedQuery(name = "Route.findByStartingFrom", query = "SELECT r FROM Route r WHERE r.startingFrom = :startingFrom")
    , @NamedQuery(name = "Route.findByDestinaion", query = "SELECT r FROM Route r WHERE r.destinaion = :destinaion")})
public class Route implements Serializable {

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "route")
    private List<Fare> fareList;

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "ROUTE_ID")
    private Long routeId;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "STARTING_FROM")
    private String startingFrom;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "DESTINAION")
    private String destinaion;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "routeId")
    private List<Flight> flightList;
    @OneToOne(cascade = CascadeType.ALL, mappedBy = "route")
    private Fare fare;

    public Route() {
    }

    public Route(Long routeId) {
        this.routeId = routeId;
    }

    public Route(Long routeId, String startingFrom, String destinaion) {
        this.routeId = routeId;
        this.startingFrom = startingFrom;
        this.destinaion = destinaion;
    }

    public Long getRouteId() {
        return routeId;
    }

    public void setRouteId(Long routeId) {
        this.routeId = routeId;
    }

    public String getStartingFrom() {
        return startingFrom;
    }

    public void setStartingFrom(String startingFrom) {
        this.startingFrom = startingFrom;
    }

    public String getDestinaion() {
        return destinaion;
    }

    public void setDestinaion(String destinaion) {
        this.destinaion = destinaion;
    }

    @XmlTransient
    public List<Flight> getFlightList() {
        return flightList;
    }

    public void setFlightList(List<Flight> flightList) {
        this.flightList = flightList;
    }

    public Fare getFare() {
        return fare;
    }

    public void setFare(Fare fare) {
        this.fare = fare;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (routeId != null ? routeId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Route)) {
            return false;
        }
        Route other = (Route) object;
        if ((this.routeId == null && other.routeId != null) || (this.routeId != null && !this.routeId.equals(other.routeId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.airline.entity.Route[ routeId=" + routeId + " ]";
    }

    @XmlTransient
    public List<Fare> getFareList() {
        return fareList;
    }

    public void setFareList(List<Fare> fareList) {
        this.fareList = fareList;
    }
    
}
