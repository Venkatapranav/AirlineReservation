/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.airline.entity;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author vadas
 */
@Embeddable
public class TicketPK implements Serializable {

    @Basic(optional = false)
    @NotNull
    @Column(name = "TICKET_ID")
    private int ticketId;
    @Basic(optional = false)
    @NotNull
    @Column(name = "CUSTOMER_ID")
    private int customerId;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "PASSENGER")
    private String passenger;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "SSN")
    private String ssn;

    public TicketPK() {
    }

    public TicketPK(int ticketId, int customerId, String passenger, String ssn) {
        this.ticketId = ticketId;
        this.customerId = customerId;
        this.passenger = passenger;
        this.ssn = ssn;
    }

    public int getTicketId() {
        return ticketId;
    }

    public void setTicketId(int ticketId) {
        this.ticketId = ticketId;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public String getPassenger() {
        return passenger;
    }

    public void setPassenger(String passenger) {
        this.passenger = passenger;
    }

    public String getSsn() {
        return ssn;
    }

    public void setSsn(String ssn) {
        this.ssn = ssn;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) ticketId;
        hash += (int) customerId;
        hash += (passenger != null ? passenger.hashCode() : 0);
        hash += (ssn != null ? ssn.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof TicketPK)) {
            return false;
        }
        TicketPK other = (TicketPK) object;
        if (this.ticketId != other.ticketId) {
            return false;
        }
        if (this.customerId != other.customerId) {
            return false;
        }
        if ((this.passenger == null && other.passenger != null) || (this.passenger != null && !this.passenger.equals(other.passenger))) {
            return false;
        }
        if ((this.ssn == null && other.ssn != null) || (this.ssn != null && !this.ssn.equals(other.ssn))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.airline.entity.TicketPK[ ticketId=" + ticketId + ", customerId=" + customerId + ", passenger=" + passenger + ", ssn=" + ssn + " ]";
    }
    
}
