/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.airline.entity;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author vadas
 */
@Embeddable
public class TicketPK implements Serializable {

    @Basic(optional = false)
    @NotNull
    @Column(name = "TICKET_ID")
    private long ticketId;
    @Basic(optional = false)
    @NotNull
    @Column(name = "CUSTOMER_ID")
    private long customerId;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "PASSENGER")
    private String passenger;

    public TicketPK() {
    }

    public TicketPK(long ticketId, long customerId, String passenger) {
        this.ticketId = ticketId;
        this.customerId = customerId;
        this.passenger = passenger;
    }

    public long getTicketId() {
        return ticketId;
    }

    public void setTicketId(long ticketId) {
        this.ticketId = ticketId;
    }

    public long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(long customerId) {
        this.customerId = customerId;
    }

    public String getPassenger() {
        return passenger;
    }

    public void setPassenger(String passenger) {
        this.passenger = passenger;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) ticketId;
        hash += (int) customerId;
        hash += (passenger != null ? passenger.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof TicketPK)) {
            return false;
        }
        TicketPK other = (TicketPK) object;
        if (this.ticketId != other.ticketId) {
            return false;
        }
        if (this.customerId != other.customerId) {
            return false;
        }
        if ((this.passenger == null && other.passenger != null) || (this.passenger != null && !this.passenger.equals(other.passenger))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.airline.entity.TicketPK[ ticketId=" + ticketId + ", customerId=" + customerId + ", passenger=" + passenger + " ]";
    }
    
}
