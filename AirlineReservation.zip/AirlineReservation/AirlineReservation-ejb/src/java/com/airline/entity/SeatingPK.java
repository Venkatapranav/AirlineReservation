/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.airline.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author vadas
 */
@Embeddable
public class SeatingPK implements Serializable {

    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "SEAT_NO")
    private String seatNo;
    @Basic(optional = false)
    @NotNull
    @Column(name = "FLIGHT_ID")
    private int flightId;
    @Basic(optional = false)
    @NotNull
    @Column(name = "DEPT_TIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deptTime;

    public SeatingPK() {
    }

    public SeatingPK(String seatNo, int flightId, Date deptTime) {
        this.seatNo = seatNo;
        this.flightId = flightId;
        this.deptTime = deptTime;
    }

    public String getSeatNo() {
        return seatNo;
    }

    public void setSeatNo(String seatNo) {
        this.seatNo = seatNo;
    }

    public int getFlightId() {
        return flightId;
    }

    public void setFlightId(int flightId) {
        this.flightId = flightId;
    }

    public Date getDeptTime() {
        return deptTime;
    }

    public void setDeptTime(Date deptTime) {
        this.deptTime = deptTime;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (seatNo != null ? seatNo.hashCode() : 0);
        hash += (int) flightId;
        hash += (deptTime != null ? deptTime.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof SeatingPK)) {
            return false;
        }
        SeatingPK other = (SeatingPK) object;
        if ((this.seatNo == null && other.seatNo != null) || (this.seatNo != null && !this.seatNo.equals(other.seatNo))) {
            return false;
        }
        if (this.flightId != other.flightId) {
            return false;
        }
        if ((this.deptTime == null && other.deptTime != null) || (this.deptTime != null && !this.deptTime.equals(other.deptTime))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.airline.entity.SeatingPK[ seatNo=" + seatNo + ", flightId=" + flightId + ", deptTime=" + deptTime + " ]";
    }
    
}
