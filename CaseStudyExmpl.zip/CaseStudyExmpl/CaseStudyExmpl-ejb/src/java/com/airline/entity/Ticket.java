/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.airline.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author adcheruk
 */
@Entity
@Table(name = "TICKET")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Ticket.findAll", query = "SELECT t FROM Ticket t")
    , @NamedQuery(name = "Ticket.findByTicketId", query = "SELECT t FROM Ticket t WHERE t.ticketId = :ticketId")
    , @NamedQuery(name = "Ticket.findByCustomerId", query = "SELECT t FROM Ticket t WHERE t.customerId = :customerId")
    , @NamedQuery(name = "Ticket.findByFlightId", query = "SELECT t FROM Ticket t WHERE t.flightId = :flightId")
    , @NamedQuery(name = "Ticket.findBySeatNo", query = "SELECT t FROM Ticket t WHERE t.seatNo = :seatNo")
    , @NamedQuery(name = "Ticket.findByDoj", query = "SELECT t FROM Ticket t WHERE t.doj = :doj")
    , @NamedQuery(name = "Ticket.findByStatus", query = "SELECT t FROM Ticket t WHERE t.status = :status")
    , @NamedQuery(name = "Ticket.findByTob", query = "SELECT t FROM Ticket t WHERE t.tob = :tob")
    , @NamedQuery(name = "Ticket.findByFare", query = "SELECT t FROM Ticket t WHERE t.fare = :fare")})

public class Ticket implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "TICKET_ID")
    private Integer ticketId;
    @Basic(optional = false)
    @NotNull
    @Column(name = "CUSTOMER_ID")
    private int customerId;
    @Column(name = "FLIGHT_ID")
    private Integer flightId;
    @Column(name = "SEAT_NO")
    private Integer seatNo;
    @Basic(optional = false)
    @NotNull
    @Column(name = "DOJ")
    @Temporal(TemporalType.DATE)
    private Date doj;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "STATUS")
    private String status;
    @Basic(optional = false)
    @NotNull
    @Column(name = "TOB")
    @Temporal(TemporalType.TIMESTAMP)
    private Date tob;
    @Basic(optional = false)
    @NotNull
    @Column(name = "FARE")
    private double fare;

    public Ticket() {
    }

    public Ticket(Integer ticketId) {
        this.ticketId = ticketId;
    }

    public Ticket(Integer ticketId, int customerId, Date doj, String status, Date tob, double fare) {
        this.ticketId = ticketId;
        this.customerId = customerId;
        this.doj = doj;
        this.status = status;
        this.tob = tob;
        this.fare = fare;
    }

    public Integer getTicketId() {
        return ticketId;
    }

    public void setTicketId(Integer ticketId) {
        this.ticketId = ticketId;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public Integer getFlightId() {
        return flightId;
    }

    public void setFlightId(Integer flightId) {
        this.flightId = flightId;
    }

    public Integer getSeatNo() {
        return seatNo;
    }

    public void setSeatNo(Integer seatNo) {
        this.seatNo = seatNo;
    }

    public Date getDoj() {
        return doj;
    }

    public void setDoj(Date doj) {
        this.doj = doj;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getTob() {
        return tob;
    }

    public void setTob(Date tob) {
        this.tob = tob;
    }

    public double getFare() {
        return fare;
    }

    public void setFare(double fare) {
        this.fare = fare;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (ticketId != null ? ticketId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Ticket)) {
            return false;
        }
        Ticket other = (Ticket) object;
        if ((this.ticketId == null && other.ticketId != null) || (this.ticketId != null && !this.ticketId.equals(other.ticketId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.airline.entity.Ticket[ ticketId=" + ticketId + " ]";
    }
    
}
