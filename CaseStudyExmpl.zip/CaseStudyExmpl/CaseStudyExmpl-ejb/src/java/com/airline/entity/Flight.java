/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.airline.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author adcheruk
 */
@Entity
@Table(name = "FLIGHT")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Flight.findAll", query = "SELECT f FROM Flight f")
    , @NamedQuery(name = "Flight.findByFlightId", query = "SELECT f FROM Flight f WHERE f.flightId = :flightId")
    , @NamedQuery(name = "Flight.findByRouteId", query = "SELECT f FROM Flight f WHERE f.routeId = :routeId")
    , @NamedQuery(name = "Flight.findByPlaneId", query = "SELECT f FROM Flight f WHERE f.planeId = :planeId")
    , @NamedQuery(name = "Flight.findByDeptDate", query = "SELECT f FROM Flight f WHERE f.deptDate = :deptDate")
    , @NamedQuery(name = "Flight.findByDeptTime", query = "SELECT f FROM Flight f WHERE f.deptTime = :deptTime")
    , @NamedQuery(name = "Flight.findByArrDate", query = "SELECT f FROM Flight f WHERE f.arrDate = :arrDate")
    , @NamedQuery(name = "Flight.findByArrTime", query = "SELECT f FROM Flight f WHERE f.arrTime = :arrTime")})
public class Flight implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "FLIGHT_ID")
    private Integer flightId;
    @Basic(optional = false)
    @NotNull
    @Column(name = "ROUTE_ID")
    private int routeId;
    @Basic(optional = false)
    @NotNull
    @Column(name = "PLANE_ID")
    private int planeId;
    @Basic(optional = false)
    @NotNull
    @Column(name = "DEPT_DATE")
    @Temporal(TemporalType.DATE)
    private Date deptDate;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 5)
    @Column(name = "DEPT_TIME")
    private String deptTime;
    @Basic(optional = false)
    @NotNull
    @Column(name = "ARR_DATE")
    @Temporal(TemporalType.DATE)
    private Date arrDate;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 5)
    @Column(name = "ARR_TIME")
    private String arrTime;

    public Flight() {
    }

    public Flight(Integer flightId) {
        this.flightId = flightId;
    }

    public Flight(Integer flightId, int routeId, int planeId, Date deptDate, String deptTime, Date arrDate, String arrTime) {
        this.flightId = flightId;
        this.routeId = routeId;
        this.planeId = planeId;
        this.deptDate = deptDate;
        this.deptTime = deptTime;
        this.arrDate = arrDate;
        this.arrTime = arrTime;
    }

    public Integer getFlightId() {
        return flightId;
    }

    public void setFlightId(Integer flightId) {
        this.flightId = flightId;
    }

    public int getRouteId() {
        return routeId;
    }

    public void setRouteId(int routeId) {
        this.routeId = routeId;
    }

    public int getPlaneId() {
        return planeId;
    }

    public void setPlaneId(int planeId) {
        this.planeId = planeId;
    }

    public Date getDeptDate() {
        return deptDate;
    }

    public void setDeptDate(Date deptDate) {
        this.deptDate = deptDate;
    }

    public String getDeptTime() {
        return deptTime;
    }

    public void setDeptTime(String deptTime) {
        this.deptTime = deptTime;
    }

    public Date getArrDate() {
        return arrDate;
    }

    public void setArrDate(Date arrDate) {
        this.arrDate = arrDate;
    }

    public String getArrTime() {
        return arrTime;
    }

    public void setArrTime(String arrTime) {
        this.arrTime = arrTime;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (flightId != null ? flightId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Flight)) {
            return false;
        }
        Flight other = (Flight) object;
        if ((this.flightId == null && other.flightId != null) || (this.flightId != null && !this.flightId.equals(other.flightId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.airline.entity.Flight[ flightId=" + flightId + " ]";
    }
    
}
