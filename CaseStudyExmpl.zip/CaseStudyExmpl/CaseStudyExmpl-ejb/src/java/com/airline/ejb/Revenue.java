/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.airline.ejb;

import com.airline.entity.Ticket;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author adcheruk
 */
@Stateless
public class Revenue implements RevenueLocal {

    @PersistenceContext(name="CaseStudyExmpl-ejbPU")
    EntityManager entityManager;
    @Override
    public Map<String,Double> generateStats(Date startDate,Date endDate){
      List<Ticket> tcktList = getTicketList(startDate, endDate);
      Map<String,Double> dateRevenue = new HashMap<>();
      DateFormat df = new SimpleDateFormat("dd/MM/YYYY");
      tcktList.forEach((tckt) -> {
          String date = df.format(tckt.getDoj());
            if (dateRevenue.containsKey(date)) {
                dateRevenue.put(date,dateRevenue.get(date)+tckt.getFare());
            }
        });
      return dateRevenue;
    }

    @Override
    public List<Ticket> getTicketList(Date startDate, Date endDate) {
        
        Query q = entityManager.createNativeQuery("select * from Ticket where status='booked' and doj between ? and ?",Ticket.class);
        q.setParameter(1,startDate);
        q.setParameter(2,endDate);
        return q.getResultList();
    }
}
