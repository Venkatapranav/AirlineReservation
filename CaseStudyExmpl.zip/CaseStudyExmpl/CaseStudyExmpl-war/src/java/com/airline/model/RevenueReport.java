/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.airline.model;

import com.airline.ejb.RevenueLocal;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.util.Date;
import java.util.Map;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import org.primefaces.model.chart.AxisType;
import org.primefaces.model.chart.DateAxis;
import org.primefaces.model.chart.LineChartModel;
import org.primefaces.model.chart.LineChartSeries;

/**
 *
 * @author adcheruk
 */
@Named(value = "report")
@SessionScoped
public class RevenueReport implements Serializable {

    private Date startDate;
    private Date endDate;
    
    private Map<String,Double> result;

    public Map<String, Double> getResult() {
        return result;
    }

    public void setResult(Map<String, Double> result) {
        this.result = result;
    }
    
    
    
    @EJB
    RevenueLocal local;
    
    
    private LineChartModel dateModel;
 
    @PostConstruct
    public void init() {
        createDateModel();
    }
 
    public LineChartModel getDateModel() {
        return dateModel;
    }

    public RevenueLocal getLocal() {
        return local;
    }

    public void setLocal(RevenueLocal local) {
        this.local = local;
    }
    
    /**
     * Creates a new instance of RevenueReport
     */
    public RevenueReport() {
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }
    public String createDateModel(){
        
       
        Map<String,Double> stats=local.generateStats(startDate, endDate);
        result=stats;
        
        dateModel = new LineChartModel();
        LineChartSeries series = new LineChartSeries();
        series.setLabel("Revenue Graph");
        stats.keySet().forEach((date) -> {
            series.set(date, stats.get(date));
        });
        dateModel.addSeries(series);
         
        dateModel.setTitle("Zoom for Details");
        dateModel.setZoom(true);
        dateModel.getAxis(AxisType.Y).setLabel("Values");
        DateAxis axis = new DateAxis("Dates");
        axis.setTickAngle(-50);
        axis.setMax(endDate);
        axis.setTickFormat("%b %#d, %y");
         
        dateModel.getAxes().put(AxisType.X, axis);
        return "success";
    }
    
}
