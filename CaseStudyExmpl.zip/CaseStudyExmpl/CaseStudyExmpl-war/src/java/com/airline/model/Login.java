/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.airline.model;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import javax.inject.Named;
import javax.enterprise.context.Dependent;
import javax.enterprise.context.RequestScoped;
import javax.faces.bean.ViewScoped;
import org.primefaces.context.RequestContext;
//import org.primefaces.PrimeFaces;

/**
 *
 * @author srrachap
 */
@Named(value = "login")
@ViewScoped
public class Login implements Serializable {

    /**
     * Creates a new instance of Login
     */
    public Login() {
    }
    
    public void signIn()
    {
        Map<String,Object> options = new HashMap<String, Object>();
            options.put("contentHeight", 340);
            options.put("height", 400);
            options.put("width",700);
            RequestContext.getCurrentInstance().openDialog("Demo",options,null);
    }
    
}
