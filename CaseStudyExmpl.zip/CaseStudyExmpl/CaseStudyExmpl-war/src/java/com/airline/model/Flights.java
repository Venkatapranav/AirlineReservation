/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.airline.model;

import com.airline.ejb.FlightsModifierLocal;
import com.airline.entity.Flight;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.EJB;

/**
 *
 * @author adcheruk
 */
@Named(value = "flight")
@SessionScoped
public class Flights implements Serializable {
    
    
    @EJB
    FlightsModifierLocal local;
    private static Integer flightId=20;
    private Integer routeId;
    private Integer planeId;
    private Date deptDate;
    private String deptTime;
    private Date arrDate;
    private String arrTime;
    
    

    /**
     * Creates a new instance of Flights
     */
    public Flights() {
    }

    public FlightsModifierLocal getLocal() {
        return local;
    }

    public void setLocal(FlightsModifierLocal local) {
        this.local = local;
    }

    public static Integer getFlightId() {
        return flightId;
    }

    public static void setFlightId(Integer flightId) {
        Flights.flightId = flightId;
    }

    public Integer getRouteId() {
        return routeId;
    }

    public void setRouteId(Integer routeId) {
        this.routeId = routeId;
    }

    public Integer getPlaneId() {
        return planeId;
    }

    public void setPlaneId(Integer planeId) {
        this.planeId = planeId;
    }

    public Date getDeptDate() {
        return deptDate;
    }

    public void setDeptDate(Date deptDate) {
        this.deptDate = deptDate;
    }

    public String getDeptTime() {
        return deptTime;
    }

    public void setDeptTime(String deptTime) {
        this.deptTime = deptTime;
    }

    public Date getArrDate() {
        return arrDate;
    }

    public void setArrDate(Date arrDate) {
        this.arrDate = arrDate;
    }

    public String getArrTime() {
        return arrTime;
    }

    public void setArrTime(String arrTime) {
        this.arrTime = arrTime;
    }

    
    
    
    public String addflight()
    {
        Flight flights = new Flight();
        flights.setFlightId(flightId);
        flights.setRouteId(routeId);
        flights.setPlaneId(planeId);
//        try {
//        flights.setDeptTime((new SimpleDateFormat("dd/MM/yyyy")).parse(deptDate));
//        flights.setArrTime((new SimpleDateFormat("dd/MM/yyyy")).parse(arrDate));
//        } catch (ParseException ex) {
//           ex.printStackTrace();
//        }
        flights.setDeptDate(deptDate);
        flights.setDeptTime(deptTime);
        flights.setArrDate(arrDate);
        flights.setArrTime(arrTime);
        
        local.addFlight(flights);
        flightId++;
       return "success";
    }
    
}
